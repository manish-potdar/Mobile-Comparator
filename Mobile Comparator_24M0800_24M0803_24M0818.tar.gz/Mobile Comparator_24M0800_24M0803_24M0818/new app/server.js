const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");
const csv = require("csv-parser");
const axios = require("axios");
const cheerio = require("cheerio");

const app = express();
const port = 5000;

app.use(cors());

// Load CSV data into memory
let products = [];
const csvFilePath = path.join(__dirname, "output1.csv");

fs.createReadStream(csvFilePath)
  .pipe(csv())
  .on("data", (row) => {
    products.push(row);
  })
  .on("end", () => {
    console.log("CSV file loaded successfully.");
  });

// Scrape Amazon for the product price
const getAmazonPrice = async (url) => {
  try {
    const { data } = await axios.get(url, { headers: { "User-Agent": "Mozilla/5.0" } });
    const $ = cheerio.load(data);

    // Try to get the price based on common selectors
    let price = $('#priceblock_ourprice').text() || $('#priceblock_dealprice').text();
    
    if (price) {
      // Clean up the price string and return it
      price = price.replace(/\s+/g, ' ').trim();
      return price;
    } else {
      return "Price not available";
    }
  } catch (error) {
    console.error("Error fetching Amazon price:", error);
    return "Error fetching price";
  }
};

// Search endpoint
app.get("/search", async (req, res) => {
  const { query } = req.query;

  if (!query) {
    return res.status(400).json({ error: "Query parameter is required." });
  }

  // Perform a simple search for matching product
  const lowerCaseQuery = query.toLowerCase();
  const matchedProducts = products.filter((product) =>
    product.Name?.toLowerCase().includes(lowerCaseQuery)
  );

  if (matchedProducts.length === 0) {
    return res.status(404).json({ error: "No matching products found." });
  }

  // Get the first matching product
  const product = matchedProducts[0];

  // Construct response for the first matching product
  const productDetails = {
    name: product.Name || "Name not available",
    launch: product.Launch || "Launch date not available",
    dimension: product.Dimension || "Dimension not available",
    weight: product.Weight || "Weight not available",
    displayType: product["Display Type"] || "Display type not available",
    displaySize: product["Display Size"] || "Display size not available",
    displayResolution:
      product["Display Resolution"] || "Display resolution not available",
    os: product.OS || "OS not available",
    chipset: product.Chipset || "Chipset not available",
    cpu: product.CPU || "CPU not available",
    memory: product.Memory || "Memory not available",
    sensors: product.Sensors || "Sensors not available",
    battery: product.Battery || "Battery not available",
    imageUrl: product.Image || null,  // Assuming image field is "Image"
    price: "Fetching price from Amazon...",  // Placeholder for now
  };

  // Get price from Amazon (assuming URL is in the 'Link' field in your CSV)
  if (product.Link) {
    productDetails.price = await getAmazonPrice(product.Link);
  }

  res.json({ product: productDetails });
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
