## PRODUCT COMPARATOR ##

This is the product comparator where you can compare products to resolve your confusion about which one to buy.

## HOW TO INSTALL? ##
Run the following commands :
(insatll npm by running command in directory and switch to app and do the same again)
$ npm install 

## HOW TO RUN? ##
Run following commands to start the application:
(for running server)
$ node server.js

(for running react - first switch to app folder and then run following)
$ npm start

## HOW TO USE ? ## 
Open the Prodct Comparator then type your products into given search boxes and then hit on search button and you will be able to view details of both the products.

## CHALLENGES FACED ##
1. We tried to scrape the data from different websites like amazon and flipkart etc, but after an amount of requests we were being blocked from scraping those websites.
   So we decided to build our own database and create our database by manually creating 200+ recent mobile phones database and saved it in a CSV file. (Used CSC just for
   the sake of simplicity, could have used different data bases like MYSQL and all).
   
2. We also tried to build the whole application in the Flask and tried to scrape the data using beautiful soup library for web scraping but there was this issue of response
   code 500 and then we decided to move our implementation from Flask to NodeJS and from beautifulsoup to cheerio.
   
3. As we were using our own dataset there was only limited data items we were able to get access to so we could have added that dropdown in search field but with the time limitation
   that was not implemented successfully.
