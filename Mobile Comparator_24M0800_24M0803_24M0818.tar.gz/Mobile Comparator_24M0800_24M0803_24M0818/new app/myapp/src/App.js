import React, { useState } from "react";
import axios from "axios";
import "./App.css";

function App() {
  const [query1, setQuery1] = useState("");
  const [query2, setQuery2] = useState("");
  const [product1, setProduct1] = useState(null);
  const [product2, setProduct2] = useState(null);
  const [loadingProduct1, setLoadingProduct1] = useState(false);
  const [loadingProduct2, setLoadingProduct2] = useState(false);
  const [error, setError] = useState("");

  const handleSearch = async (e, productId) => {
    e.preventDefault();
    setError("");

    if (productId === 1) setLoadingProduct1(true);
    else setLoadingProduct2(true);

    try {
      const query = productId === 1 ? query1 : query2;
      const response = await axios.get(
        `http://localhost:5000/search?query=${encodeURIComponent(query)}`
      );

      if (productId === 1) setProduct1(response.data.product);
      else setProduct2(response.data.product);
    } catch (err) {
      setError("Failed to fetch product details.");
    } finally {
      if (productId === 1) setLoadingProduct1(false);
      else setLoadingProduct2(false);
    }
  };

  const renderProductDetails = (product) => (
    <div className="product-card">
      <h2>{product.name}</h2>
      {product.imageUrl && <img src={product.imageUrl} alt={product.name} className="product-image" />}
      <table>
        <tbody>
          <tr>
            <th>Launch</th>
            <td>{product.launch}</td>
          </tr>
          <tr>
            <th>Dimension</th>
            <td>{product.dimension}</td>
          </tr>
          <tr>
            <th>Weight</th>
            <td>{product.weight}</td>
          </tr>
          <tr>
            <th>Display Type</th>
            <td>{product.displayType}</td>
          </tr>
          <tr>
            <th>Display Size</th>
            <td>{product.displaySize}</td>
          </tr>
          <tr>
            <th>Display Resolution</th>
            <td>{product.displayResolution}</td>
          </tr>
          <tr>
            <th>OS</th>
            <td>{product.os}</td>
          </tr>
          <tr>
            <th>Chipset</th>
            <td>{product.chipset}</td>
          </tr>
          <tr>
            <th>CPU</th>
            <td>{product.cpu}</td>
          </tr>
          <tr>
            <th>Memory</th>
            <td>{product.memory}</td>
          </tr>
          <tr>
            <th>Sensors</th>
            <td>{product.sensors}</td>
          </tr>
          <tr>
            <th>Battery</th>
            <td>{product.battery}</td>
          </tr>
          {product.price && (
            <tr>
              <th>Price</th>
              <td>{product.price}</td>
            </tr>
          )}
        </tbody>
      </table>
      <a href={product.link} target="_blank" rel="noopener noreferrer">
        View on Amazon
      </a>
    </div>
  );

  return (
    <div className="App">
      <h1>Product Comparator</h1>
      <div className="search-container">
        <form onSubmit={(e) => handleSearch(e, 1)} className="search-form">
          <input
            type="text"
            placeholder="Enter product name"
            value={query1}
            onChange={(e) => setQuery1(e.target.value)}
            required
          />
          <button type="submit" disabled={loadingProduct1}>
            {loadingProduct1 ? "Loading..." : "Search"}
          </button>
        </form>
        <form onSubmit={(e) => handleSearch(e, 2)} className="search-form">
          <input
            type="text"
            placeholder="Enter product name"
            value={query2}
            onChange={(e) => setQuery2(e.target.value)}
            required
          />
          <button type="submit" disabled={loadingProduct2}>
            {loadingProduct2 ? "Loading..." : "Search"}
          </button>
        </form>
      </div>

      {error && <p className="error">{error}</p>}

      <div className="product-cards-container">
        {product1 && renderProductDetails(product1)}
        {product2 && renderProductDetails(product2)}
      </div>
    </div>
  );
}

export default App;
